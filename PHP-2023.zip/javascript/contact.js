

// ver 3: has scroll bar but is often not smooth
var container = document.getElementById("container");
var threshold = 100; // Adjust this threshold as needed
var scrollTop = window.pageYOffset * 0.85;

window.onscroll = function() {
  scrollTop = window.pageYOffset * 0.85;

  // Reset scrollTop to zero if it goes below the threshold
  container.style.transform = "rotate(30deg) translateX(calc(50vw - " + scrollTop + "px))";
};

// // ver 2: has scroll bar but is often not smooth
// var container = document.getElementById("container");
// var threshold = 100; // Adjust this threshold as needed
// var scrollTop = window.pageYOffset * 0.85;

// window.onscroll = function() {
//   scrollTop = window.pageYOffset * 0.85;

//   // Reset scrollTop to zero if it goes below the threshold

//   container.style.transform =
//     "rotate(30deg) translateY(calc(80vw - 50vh + " + scrollTop + "px)) translateX(-75vw)";
// };
// // ver 1: very smooth but no scroll bar
// let container = document.getElementById("container");
// let translateX = -75; // Starting value
// let prev =0;
// //stop scrollin
// const windowWidth = window.innerWidth;
// var width = container.offsetWidth/windowWidth*-100;


// function updateScroll(event) {
//   console.log(event.deltaY);
//     if ((translateX<=-75 && translateX>=width )||(translateX>-75 && event.deltaY>0) ||(translateX<width && event.deltaY<0)){
//     translateX += event.deltaY * 0.1 *-1;
//     }


//   container.style.transform =
//     "rotate(30deg) translateX(" + translateX + "vw) translateY(calc(80vw - 50vh))";


// }

// // Wrap the wheel event listener inside a function
// function initSmoothScroll() {
//   // Remove any existing wheel listeners to prevent them from stacking
//   window.removeEventListener("wheel", updateScroll);

//   // Listen for wheel events
//   window.addEventListener("wheel", function (event) {
//     // Request animation frame ensures smoother animation
//     requestAnimationFrame(function () {
//       updateScroll(event);
//     });
//   });
// }

// // Call the initSmoothScroll function to initialize smooth scrolling
// initSmoothScroll();

// // Initial call to set the initial state
// updateScroll({ deltaY: 0 });





//Links

document.addEventListener("DOMContentLoaded", function () {
  // Assuming you have the SVG elements with the specified IDs
  const mailSvg = document.getElementById("mail");
  const phoneSvg = document.getElementById("phone");
  const facebookSvg = document.getElementById("facebook");

  // Click event for the mail SVG
  mailSvg.addEventListener("click", function () {
    window.location.href = "mailto:hiroteabaratl@gmail.com";
  });

  // Click event for the phone SVG
  phoneSvg.addEventListener("click", function () {
    window.location.href = "tel:4046559086";
  });

  // Click event for the Facebook SVG
  facebookSvg.addEventListener("click", function () {
    window.open("https://www.facebook.com/HiroTeaATL/", "_blank");
  });
});


function scrollFunction() {
if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
  document.getElementById("navBar").style.padding = "2.5px 10px";
  document.getElementById("logo").style.fontSize = "50px";
} else {
  document.getElementById("navBar").style.padding = "10px 10px";
  document.getElementById("logo").style.fontSize = "100px";
}
}