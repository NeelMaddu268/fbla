const boba = document.querySelector("#boba");
console.log(boba.offsetWidth);
const bobaHeader = document.querySelector('#bobaHeader');
const bobaText = document.querySelector('#bobaText');
let offset = pageYOffset - 400; // size of navbar

//icesDiv and ices have to be seperate so that tranform is just upplied too the ices
const icesDiv =  document.querySelectorAll('#float');
const ices = document.querySelectorAll('#ice')

var bobaWidth = 4000;
var neg = 0;
var max;
console.log(screen.width);
max  = (screen.width/bobaWidth);
if (max<0.8){
  max  = Math.sqrt(max);
  max = Math.sqrt(max);
}
console.log(max);
var min =0.01;




//sets each ice cube to have a random rotation from 0 to 360 degrees
for(i=0;i<ices.length;i++){//ices.length = icesDiv.length
    // console.log(Math.random()*360);
    // neg = Math.random() < 0.5 ? -1 : 1;
    ices[i].style.transform = 'rotate('+ Math.random()*360 +'deg) scale(0.7)';
    // var left  = Math.random() * screen.width;
    // console.log(left);
    // // check if value is cube is too far off the right
    // if (left > screen.width-50 ){
    //   left -=300;
    // }
    // else if (left+100< 200){
    //   left+=200;
    // }
      
    // icesDiv[i].style.left = left +'px';
    // icesDiv[i].style.top = Math.random()*800+'px';


}
//removes the initial blur
boba.style.transform = 'scale(' + min +0.001 + ')';
window.addEventListener('scroll', function () {
  if(screen.width>1000){
  requestAnimationFrame(bobaFunc);
  }
});

function bobaFunc() {
  max  = (screen.width/bobaWidth);
  if (max<0.8){
  max  = Math.sqrt(max);
}
  offset = pageYOffset - 400;

  const growthRate = 0.002;

  if (offset * growthRate < min) {
    boba.style.transform = 'scale(' + min+ ')';
    // text.style.transform  = 'scale(' + min+ ')';
  } else if (offset * growthRate > min&& offset * growthRate < max) {
    boba.style.transform = 'scale(' + offset * growthRate + ')';
    // text.style.transform  = 'scale(' + 1/(offset * growthRate * 1.1) + 
      ')';
  } else if (offset * growthRate >= max) {
    boba.style.transform = 'scale(' + max + ')';
    // text.style.transform = 'scale(' + 1/1.80+')';
  }
  if (offset *growthRate >=0.4){
    bobaHeader.style.opacity =1;
    bobaText.style.opacity  = 1;
    //make starggered
  }else{
    bobaText.style.opacity  = 0;
    
    bobaHeader.style.opacity =0;
  }
  scrollFunction();
}




function scrollFunction() {
  if (document.body.scrollTop > 50) {
    document.getElementById("navBar").style.padding = "2.5px 10px";
    document.getElementById("logo").style.fontSize = "50px";
    if ( window.innerWidth <=1000){
    document.getElementById("navLinks").style.top = "132.5px";
    }
  } else if(document.body.scrollTop < 40) {
    document.getElementById("navBar").style.padding = "10px 10px";
    document.getElementById("logo").style.fontSize = "100px";    
    if ( window.innerWidth<=1000){
    document.getElementById("navLinks").style.top = "145px";
    }
  }
}